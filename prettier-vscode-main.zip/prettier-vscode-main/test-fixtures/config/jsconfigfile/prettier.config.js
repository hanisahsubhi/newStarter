module.exports = {
   tabWidth: 3
};
