function foo() {
   const foo = [
      "aaaaaaaaa",
      "bbbbbb",
      "c",
      "a",
      "b",
      "c",
      "a",
      "b",
      "c",
      "a",
      "b",
      "c",
   ];
}
