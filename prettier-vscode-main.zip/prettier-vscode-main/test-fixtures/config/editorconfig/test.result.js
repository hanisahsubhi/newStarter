function foo() {
   console.log("test");
}
