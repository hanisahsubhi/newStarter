function ugly(a    ,    b ,c){
    
    
    return    a + 

    b;
}