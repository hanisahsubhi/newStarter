function ugly(a :   object,    x:any):string{
    return " xxx";
}