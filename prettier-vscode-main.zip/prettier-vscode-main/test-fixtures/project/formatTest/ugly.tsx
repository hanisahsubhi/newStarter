const f = 
    <T, >() =>   1