// .prettierignore specifies ignoring files in /subdir/*.

function test() {


    
}
