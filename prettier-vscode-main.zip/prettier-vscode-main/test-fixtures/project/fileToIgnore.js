// .prettierignore specifies ignoring fileToIgnore.js

function test() {



}
