// .prettierignore specifies ignoring files in /subdir/subdir.

function test() {


    
}
